# Minecraft-Image-to-Map-DataPack
This is a project for auto load maps into world created by third-party software which is used to turn images into Minecraft maps.  
for image converter, jump here https://github.com/tryashtar/image-map